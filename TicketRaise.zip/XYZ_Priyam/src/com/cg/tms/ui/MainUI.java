package com.cg.tms.ui;

import java.time.LocalDateTime;
import java.util.Scanner;

import com.cg.tms.dao.TicketDAO;
import com.cg.tms.dao.TicketDAOImpl;
import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.service.TicketService;
import com.cg.tms.service.TicketServiceImpl;

public class MainUI {
	private static TicketDAO ticketDAO = new TicketDAOImpl();
	private static TicketService ticketService = new TicketServiceImpl(ticketDAO);
	private static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
		int choice = 0;
		while (true) {
			System.out.println("------------------------------Menu-----------------------");
			System.out.println("1.Raise Ticket");
			System.out.println("2. Exit from the system");
			choice = scanner.nextInt();
			switch (choice) {
			case 1:
				raiseTicket();
				break;
			case 2:
				scanner.close();
				System.exit(0);
				break;
			default:
				System.out.println("You have entered an invalid choice");

			}

		}

	}

	public static void raiseTicket() {

		System.out.println("Enter the ticket Category");
		System.out.println("1. software installation");
		System.out.println("2. mailbox creation");
		System.out.println("3. mailbox issues");
		int n = scanner.nextInt();
		TicketCategory ticketCategory = ticketService.getCategory(n);
		scanner.nextLine();
		System.out.println("Enter Ticket Description");
		String Description = scanner.nextLine();
		System.out.println("Ticked Priority(1.low 2.medium 3.high):");
		String priority = scanner.nextLine();
		String status = "New";
		String ticketNo = Integer.toString((int)( Math.random() * 1000));
		TicketBean ticketBean = new TicketBean(ticketNo, ticketCategory, Description, priority, status, "");
		ticketService.raiseNewTicket(ticketBean);

		System.out.println("Ticket Number" + ticketNo + " logged successfully at " + LocalDateTime.now());

	}

}
