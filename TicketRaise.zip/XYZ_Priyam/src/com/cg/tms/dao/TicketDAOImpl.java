package com.cg.tms.dao;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
public class TicketDAOImpl implements TicketDAO
{
private static Map<String,String> ticketCategory=new HashMap<String,String>();
private static Map<String,TicketBean> ticketLog=new HashMap<>();
public static Map<String,String> getTicketCategoryEntries()
{
	ticketCategory.put("tc001", "software installation");
	ticketCategory.put("tc002", "mailbox creation");
	ticketCategory.put("tc003", "mailbox issues");
	return ticketCategory;
}

	@Override
	public boolean raiseNewTicket(TicketBean ticketBean) 
	{
		ticketLog.put(ticketBean.getTicketNo(), ticketBean);
		return true;
     
	}
	@Override
	public List<TicketCategory> listTicketCategory()
	{
		List<TicketCategory> list=new LinkedList(ticketCategory.values());
		return list;
	}

	public TicketCategory getCategory(int id)
	{
		TicketCategory ticket=new TicketCategory();
		if(id==1)
		{
			ticket.setTicketCategoryid("tc001");
			ticket.setCategoryName(ticketCategory.get("tc001"));
		}
		else if(id==2)
		{
			ticket.setTicketCategoryid("tc001");
			ticket.setCategoryName(ticketCategory.get("tc002"));
		}
		else if(id==3)
		{
			ticket.setTicketCategoryid("tc001");
			ticket.setCategoryName(ticketCategory.get("tc003"));
		}
		else
		{
			
		}
		return ticket;
		
	}
	
	
	
	

}
